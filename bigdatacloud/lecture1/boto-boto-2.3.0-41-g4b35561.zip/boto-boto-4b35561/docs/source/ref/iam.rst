.. ref-iam

===
IAM
===

boto.iam
--------

.. automodule:: boto.iam
   :members:   
   :undoc-members:

boto.iam.connection
-------------------

.. automodule:: boto.iam.connection
   :members:   
   :undoc-members:

boto.iam.summarymap
-------------------

.. automodule:: boto.iam.summarymap
   :members:   
   :undoc-members:

