#!/bin/bash

echo ""
java -cp saxon9he.jar net.sf.saxon.Query $1
echo $'\n'

