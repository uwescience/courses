Run the following comand in this directory:

    java -cp saxon9he.jar net.sf.saxon.Query q01.xq

Repeat for q02.xq etc

Alternatively, use

   run.sh q01.xq

To generate ps, run the following command:

   cat q*.xq | enscript -3 -r -j -p q-all.ps


To create tar file run:

    tar cvf XML-LECTURE-QUERIES.tar --exclude XML-LECTURE-QUERIES/.svn  XML-LECTURE-QUERIES/
    gzip XML-LECTURE-QUERIES.tar
